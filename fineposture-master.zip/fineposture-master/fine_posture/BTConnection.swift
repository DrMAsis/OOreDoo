//
//  BTConnection.swift
//  fine_posture
//
//  Created by Mahsa on 4/8/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import CoreBluetooth
import SwiftEventBus

enum ConnectionState {
    
    case Off
    case Searching
    case Connected
    case Connecting
    case Disconnected
}

public class BTConnection : NSObject , CBCentralManagerDelegate, CBPeripheralDelegate
{
    public static let shared = BTConnection.init()
 
    public static let EVENT_CONNECTION_STATE = "connection_state"
    public static let EVENT_DATA_UPDATE = "data_update"
    public static let EVENT_SETTING_UPDATE = "setting_update"

    
    var connectionState : ConnectionState = .Disconnected
    {
        didSet {
            SwiftEventBus.post(BTConnection.EVENT_CONNECTION_STATE)
        }
    }
    
    let centralQueue: DispatchQueue = DispatchQueue(label: "com.fine.posture", attributes: .concurrent)

    
    /// real time data
    var finalAng : Int?
    var finalError : Int?
    var finalBattery : Int?
    /// real time data log
    var finalAlertNumLog : Int? {
        didSet { updateLog() }
    }
    var finalMeanLog : Int? {
        didSet { updateLog() }
    }
    var finalTimeLog : Int?
    /// chars
    var angleChar : CBCharacteristic!
    var errorChar : CBCharacteristic!
    var batteryChar : CBCharacteristic!
    var alertNumChar : CBCharacteristic!
    var meanChar : CBCharacteristic!

    var setPointChar : CBCharacteristic!
    var negativeErrorChar : CBCharacteristic!
    var positiveErrorChar : CBCharacteristic!
    var vibrateTimeChar : CBCharacteristic!
    var realTimeChar : CBCharacteristic!
    var resetHistoryChar : CBCharacteristic!
    var hardResetChar : CBCharacteristic!
    var volumeChar : CBCharacteristic!
    
    //let UP_DEV_UUID =     CBUUID(string: "7CDE985B-42C1-5FB8-6564-61E80F76D2D0")
    let UP_DEV_UUID = CBUUID(string: "E589676E-C04F-325A-70A0-C7B052E08C25")
    let UP_SERVICE_UUID = CBUUID(string: "EBE858F3-C586-4A05-9F27-CD655E145264")
    let UP_SETTING_UUID = CBUUID(string: "4D4E8020-02CB-4BF7-8CF0-BC9E6088E95F")
    let UP_LOG_UUID = CBUUID(string: "65295921-CB4B-4929-83D4-579AFB6AF69D")

    
    var manager : CBCentralManager!
    var myPeripheral  :CBPeripheral!
    
    var timer : Timer!
    
    var savedHistory = false
    
    override init() {
        super.init()
        
        timer = Timer.scheduledTimer(timeInterval: 7, target: self, selector: #selector(checkForConnection), userInfo: nil, repeats: true)
        
        manager = CBCentralManager(delegate: self, queue: centralQueue)
        
    }
    
    public func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
        print("BT STATE : \(central.state.rawValue)")
        
        switch central.state {
        case .poweredOn:
            
            connectionState = .Searching
            
            manager.scanForPeripherals(withServices: nil, options: nil)
            
            manager.stopScan()
            
            timer.fire()

            manager.scanForPeripherals(withServices: nil, options: nil)
            
        case .poweredOff:
            connectionState = .Off
            
        default:
            connectionState = .Disconnected
        }
    }
    
    private func updateLog()
    {
        guard !savedHistory , resetHistoryChar != nil , finalMeanLog != nil , finalAlertNumLog != nil else {
            return
        }
        
        _ = CoreDataHandler.saveLogObject(dateTime: Date(), errorCount: Int32(finalAlertNumLog!), average: Int32(finalMeanLog!), errorTime: 0)
        writeValue(value: 1, for: resetHistoryChar)
        
        savedHistory = true
    }
    
    @objc private func checkForConnection()
    {
        if nearestPeripheral != nil
        {
            connectionState = .Connecting
            manager.stopScan()
            myPeripheral = nearestPeripheral?.peripheral
            myPeripheral.delegate = self
            manager.connect(myPeripheral, options: nil)
            timer.invalidate()
        }
    }
    
    public func connect()
    {
        if manager.state == .poweredOn && !manager.isScanning
        {
            if myPeripheral != nil
            {
                connectionState = .Connecting
                manager.connect(myPeripheral, options: nil)
            }
            else {
                connectionState = .Searching
                
                manager.scanForPeripherals(withServices: nil, options: nil)
                
                manager.stopScan()
                
                timer.fire()
                
                manager.scanForPeripherals(withServices: nil, options: nil)
            }
        }
    }
    
    public func disconnect()
    {
        timer.invalidate()
        if manager != nil && myPeripheral != nil
        {
            manager.cancelPeripheralConnection(myPeripheral)
        }
        
        connectionState = .Disconnected
    }
    
    var nearestPeripheral : (peripheral : CBPeripheral , rrsi : NSNumber)?
    
    public func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        print("BT STATE : found peripheral \(peripheral.name)")
        
        if peripheral.name == "Virtual Brace"
        {
            if nearestPeripheral != nil
            {
                if RSSI.compare(nearestPeripheral!.rrsi) == .orderedDescending
                {
                    nearestPeripheral = (peripheral : peripheral , rrsi : RSSI)
                }
            }
            else {
                nearestPeripheral = (peripheral : peripheral , rrsi : RSSI)
            }
        }
    }
    
    public func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        print("BT STATE : connected to peripheral")
        peripheral.discoverServices([UP_SERVICE_UUID, UP_LOG_UUID, UP_SETTING_UUID])
        
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        
        if error != nil {
            print("BT STATE :  error discovering services: \(error!.localizedDescription)")
            connectionState = .Disconnected
            return
        }
        guard let services = peripheral.services else {
            connectionState = .Disconnected
            return
        }
        //We need to discover the all characteristic
        for service in services {
            peripheral.discoverCharacteristics(nil, for: service)
        }
        
        connectionState = .Connected

        print("BT STATE : discovered services for peripheral")
    }

    
    public func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        
        if error != nil {
            print("BT STATE : error discovering characteristics: \(error!.localizedDescription)")
            connectionState = .Disconnected
            return
        }
        guard let characteristics = service.characteristics else {
            connectionState = .Disconnected
            return
        }
        
        print("BT STATE : found \(characteristics.count) characteristics!")
        

        
        if(service.uuid.uuidString == UP_SERVICE_UUID.uuidString) {
            angleChar   = characteristics[0]
            errorChar   = characteristics[1]
            batteryChar = characteristics[2]
            peripheral.setNotifyValue(true, for: angleChar)
            peripheral.readValue(for: angleChar)
            peripheral.setNotifyValue(true, for: errorChar)
            peripheral.readValue(for: errorChar)
            peripheral.setNotifyValue(true, for: batteryChar)
            peripheral.readValue(for: batteryChar)
        }
        else if(service.uuid.uuidString == UP_SETTING_UUID.uuidString) {
            setPointChar      = characteristics[0]
            negativeErrorChar = characteristics[1]
            positiveErrorChar = characteristics[2]
            vibrateTimeChar   = characteristics[3]
            realTimeChar      = characteristics[4]
            resetHistoryChar  = characteristics[5]
            hardResetChar     = characteristics[6]
            volumeChar        = characteristics[7]
            
            let valueString = ("1" as NSString).data(using: String.Encoding.utf8.rawValue)
            myPeripheral.writeValue(valueString!, for: realTimeChar, type : CBCharacteristicWriteType.withResponse)
            UserDefaults.standard.set(true, forKey: UserDefaults.Key.SETTING_ON_OFF)
            
            peripheral.readValue(for: negativeErrorChar)
            peripheral.readValue(for: positiveErrorChar)
            peripheral.readValue(for: vibrateTimeChar)
            peripheral.readValue(for: volumeChar)
            peripheral.readValue(for: setPointChar)

            
        }
        else if(service.uuid.uuidString == UP_LOG_UUID.uuidString) {
            alertNumChar = characteristics[1]
            meanChar     = characteristics[0]
            peripheral.setNotifyValue(true, for: alertNumChar)
            peripheral.readValue(for: alertNumChar)
            peripheral.setNotifyValue(true, for: meanChar)
            peripheral.readValue(for: meanChar)
        }
        
        SwiftEventBus.post(BTConnection.EVENT_DATA_UPDATE)

    }
    
    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("Did disconnect from peripheral")
    }
    
    public func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        
        //Angle Char
        if(characteristic == angleChar) {
            finalAng = convertASCII(data: characteristic)
            SwiftEventBus.post(BTConnection.EVENT_DATA_UPDATE)

        }
        
        //Real Time Error
        else if(characteristic == errorChar) {
            finalError = convertASCII(data: characteristic)
            SwiftEventBus.post(BTConnection.EVENT_DATA_UPDATE)

        }
            //log alert Num Error
        else if(characteristic == alertNumChar) {
            finalAlertNumLog = convertASCII(data: characteristic)
            SwiftEventBus.post(BTConnection.EVENT_DATA_UPDATE)

        }
            //log Mean
        else if(characteristic == meanChar) {
            finalMeanLog = convertASCII(data: characteristic)
            SwiftEventBus.post(BTConnection.EVENT_DATA_UPDATE)

        }
            //log Battery
        else if(characteristic == batteryChar) {
            finalBattery = convertASCII(data: characteristic)
            SwiftEventBus.post(BTConnection.EVENT_DATA_UPDATE)
        }
        
        else if(characteristic == setPointChar) {
            let error = convertASCII(data: characteristic)

            UserDefaults.standard.set(error, forKey: UserDefaults.Key.SETTING_SET_POINT)
            SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        }
            
        else if(characteristic == positiveErrorChar) {
            let error = convertASCII(data: characteristic)

            UserDefaults.standard.set(error, forKey: UserDefaults.Key.SETTING_ERROR_POSITIVE)
            SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        }
        
        else if(characteristic == negativeErrorChar) {
            let error = convertASCII(data: characteristic)

            UserDefaults.standard.set(error, forKey: UserDefaults.Key.SETTING_ERROR_NEGATIVE)
            SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        }
        
        else if(characteristic == volumeChar) {
            let volume = convertASCII(data: characteristic)
            UserDefaults.standard.set(volume, forKey: UserDefaults.Key.SETTING_ALARM_VOLUME)
            SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        }
        
        else if(characteristic == vibrateTimeChar) {
            let time = convertASCII(data: characteristic)
            UserDefaults.standard.set(time, forKey: UserDefaults.Key.SETTING_ALARM_DELAY)
            SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        }
    }
    
    public func writeValue(value : Int , for characteristic : CBCharacteristic?)
    {
        guard myPeripheral != nil , characteristic != nil else {
            return
        }
        
        let valueString = NSString(string: "\(value)").data(using: String.Encoding.utf8.rawValue)
        myPeripheral.writeValue(valueString!, for: characteristic!, type : CBCharacteristicWriteType.withResponse)
    }
    
    
    func convertASCII(data : CBCharacteristic) -> Int? {
        var retVal : Int = 0
        if data.value != nil {
            let ASCIIstring = NSString(data: data.value!, encoding: String.Encoding.utf8.rawValue)
            retVal = Int((ASCIIstring?.doubleValue)!)
        } else {
            return nil
        }
        return retVal
    }
    
}
