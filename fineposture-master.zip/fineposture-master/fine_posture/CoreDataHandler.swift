//
//  coreDataHandler.swift
//  upRightV1
//
//  Created by milad on 2/22/18.
//  Copyright © milad. All rights reserved.
//

import UIKit
import CoreData

class CoreDataHandler: NSObject {
    
    public static var context : NSManagedObjectContext?
    
    
////Save log
    class func saveLogObject(dateTime: Date,errorCount :Int32,average :Int32,errorTime :Int32) -> Bool {
        let entity = NSEntityDescription.entity(forEntityName: "Log", in: context!)
        let manageObject = NSManagedObject(entity: entity!, insertInto: context!)
        manageObject.setValue(dateTime, forKey: "date")
        manageObject.setValue(errorCount, forKey: "errorNum")
        manageObject.setValue(average, forKey: "average")
        manageObject.setValue(errorTime, forKey: "timeError")
        do {
            try context?.save()
            return true
        } catch {
            return false
        }
    }
////Fetch log
    class func fetchLogObject() -> [Log]? {
        var log : [Log]? = nil
        do {
            log = try context?.fetch(Log.fetchRequest())
            return log
        } catch {
            return log
        }
    }
////Delete log
    class func deleteLogObject(log : Log) -> Bool{
        context?.delete(log)
        do {
            try context?.save()
            return true
        } catch {
            return false
        }
    }
    
    class func deleteWholeLog() -> Bool {
        let delete = NSBatchDeleteRequest(fetchRequest: Log.fetchRequest())
        do {
            try context?.execute(delete)
            return true
        } catch {
            return false
        }
    }
}
