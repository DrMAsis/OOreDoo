//
//  CalibratedView.swift
//  fine_posture
//
//  Created by Mahsa on 4/3/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import UIKit

class CalibratedCircleView : UIView
{
    private let steps = 90
    private var stepRadian : CGFloat!
    
    private var circle : CGRect!
    private var padding : CGFloat!
    
    private let startColor = UIColor(red: 98 / 244, green: 163 / 255, blue: 33 / 255, alpha: 1)
    private let endColor = UIColor(red: 199 / 255, green: 67 / 255, blue: 12 / 255, alpha: 1)
    
    let shapeLayer = CAShapeLayer()
    let gradientLayer = CAGradientLayer()

    let triangleImage = UIImageView(image: UIImage(named: "img_triangle"))
    let dummyTop = UIImageView(image: UIImage(named: "img_dummy_top"))
    let dummyBottom = UIImageView(image: UIImage(named: "img_dummy_bottom"))

    var dummyWidth : CGFloat!
    var dummyBottomHeight : CGFloat!
    var dummyTopHeight : CGFloat!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        commonInit()
    }
    
    func commonInit()
    {
        triangleImage.frame.size = CGSize(width: 25, height: 25)
        self.addSubview(triangleImage)
        
//        dummyBottom.contentMode = .scaleAspectFit
//        addSubview(dummyBottom)
//        dummyBottom.tintColor = UIColor(named: "primary")!
        
        dummyTop.contentMode = .scaleAspectFit
        addSubview(dummyTop)
        dummyTop.tintColor = UIColor(named: "primary")!

    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        
        stepRadian = CGFloat.pi * 2 / CGFloat(steps)
        
        padding = frame.width / 7
        circle = CGRect(x: (frame.width - frame.height + padding ) / 2 , y: padding / 2, width: frame.height - padding, height: frame.height - padding)

    }
    
    override func draw(_ rect: CGRect) {

        
        if let context = UIGraphicsGetCurrentContext()
        {
            context.setStrokeColor(UIColor(named: "primary")!.cgColor)
            context.setLineWidth(8)
            context.strokeEllipse(in: circle)
        }
        
        let offset = CGPoint(x: circle.midX, y: center.y)
        let start : CGFloat = (frame.height / 2) - (padding / 4)
        let end : CGFloat = start + padding / 8
        
        let path = UIBezierPath()
        
        for i in 0 ..< self.steps
        {
            let x = cos(CGFloat(i) * stepRadian)
            let y = sin(CGFloat(i) * stepRadian)
            
            
            path.move(to: CGPoint(x: offset.x + x * start, y: offset.y + y * start))
            path.addLine(to: CGPoint(x: offset.x + x * end, y: offset.y + y * end))
        }
        
        shapeLayer.path = path.cgPath
        shapeLayer.lineWidth = 4
        shapeLayer.lineCap = .round
        shapeLayer.strokeColor = endColor.cgColor
        
        gradientLayer.frame = CGRect(origin: .zero, size: frame.size)
        gradientLayer.colors = [startColor.cgColor , endColor.cgColor]

        gradientLayer.startPoint = CGPoint(x: 0.5 , y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        gradientLayer.mask = shapeLayer
        
        self.layer.addSublayer(gradientLayer)
        
        triangleImage.center = CGPoint(x: circle.midX, y: -padding / 4)
        
        dummyWidth = 0.17 * frame.width
        dummyBottomHeight = 0.17 * frame.height
        dummyTopHeight = 0.34 * frame.height
        
        
//        dummyBottom.frame.size = CGSize(width: dummyWidth, height: dummyBottomHeight)
        dummyTop.frame.size = CGSize(width: dummyWidth , height: dummyTopHeight)
        
//        let dummyBottomDistance = circle.midY - 0.25 * dummyBottomHeight
        
        
//        dummyBottom.frame.origin = CGPoint(x: circle.midX - (dummyWidth / 2), y: dummyBottomDistance)
        
        dummyTop.frame.origin = CGPoint(x: circle.midX - (dummyWidth / 2), y: circle.midY - dummyTopHeight)
    }
    
    func setAngle( angle : Double )
    {
        let radianAngle = CGFloat(-angle) * CGFloat.pi / 180
        let transformAngle = radianAngle - (3 * CGFloat.pi / 2)
        
        
        let x = cos(radianAngle)
        let y = sin(radianAngle)
        
        

        let offset = CGPoint(x: circle.midX , y: center.y)
        let position : CGFloat = (circle.height / 2) + 5 * padding / 6
        
        setAnchorPoint(anchorPoint: CGPoint(x: 0.5, y: 1), view: dummyTop)

        
        let newPoint = CGPoint(x: offset.x + x * position, y: offset.y + y * position)
        
        UIView.animate(withDuration: 0.5, animations: {
            
            
            self.triangleImage.transform = CGAffineTransform(rotationAngle: transformAngle)
            self.dummyTop.transform = CGAffineTransform(rotationAngle: transformAngle)
            self.triangleImage.center = newPoint
            
        })
        
    }
    
    func setAnchorPoint(anchorPoint: CGPoint, view: UIView) {
        
        var newPoint = CGPoint(x: view.bounds.size.width * anchorPoint.x, y: view.bounds.size.height * anchorPoint.y)
        var oldPoint = CGPoint(x: view.bounds.size.width * view.layer.anchorPoint.x, y: view.bounds.size.height * view.layer.anchorPoint.y)
        
        newPoint = newPoint.applying(view.transform)
        oldPoint = oldPoint.applying(view.transform)
        
        var position : CGPoint = view.layer.position
        
        position.x -= oldPoint.x
        position.x += newPoint.x
        
        position.y -= oldPoint.y
        position.y += newPoint.y
        
        view.layer.position = position
        view.layer.anchorPoint = anchorPoint
    }
    
    
}
