//
//  CircleView.swift
//  fine_posture
//
//  Created by Mahsa on 4/3/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import UIKit

class CircleView : UIView
{
    
    override func draw(_ rect: CGRect) {
        
        let padding : CGFloat = 15
        var size : CGFloat!
        
        if self.layer.frame.width >= self.layer.frame.height
        {
            size = self.layer.frame.height - padding
        }
        else {
            size = self.layer.frame.width - padding
        }
        
        if let context = UIGraphicsGetCurrentContext()
        {
            context.setStrokeColor(UIColor(named: "primary")!.cgColor)
            context.setLineWidth(8)
            context.strokeEllipse(in: CGRect(x: ( frame.width - size ) / 2, y: ( frame.height - size ) / 2, width: size, height: size))
        }
    }
}
