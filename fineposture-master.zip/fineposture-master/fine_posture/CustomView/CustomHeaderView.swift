//
//  CustomHeaderView.swift
//  fine_posture
//
//  Created by Mahsa on 3/24/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import UIKit

class CustomHeaderView : UIView
{
    var radius1 : CGFloat!
    var angle1 : CGFloat!
    
    var radius2 : CGFloat!
    var angle2 : CGFloat!
    
    override func layoutSubviews() {
        
        
        let h = self.frame.height / 5
        let w = self.frame.width * 2 / 5
        
        self.radius1 = (h / 2) +  (w * w / (2 * h))
        let d = radius1 - h
        
        self.angle1 = acos(d / radius1)
    
        
        let h2 = self.frame.height / 3
        let w2 = self.frame.width * 3 / 5
        
        self.radius2 = (h2 / 2) +  (w2 * w2 / (2 * h2))
        let d2 = radius2 - h2
        
        self.angle2 = acos(d2 / radius2)
    }
    
    
    override func draw(_ rect: CGRect) {
        
        if let context = UIGraphicsGetCurrentContext()
        {
            let startPoint = self.frame.height * 3 / 10
            let startAngle = 3 * CGFloat.pi / 2
            let path = UIBezierPath()
            path.move(to: CGPoint(x: 0, y: startPoint))
            path.addArc(withCenter: CGPoint(x: 0, y: startPoint + radius1), radius: radius1, startAngle: startAngle , endAngle: startAngle + angle1 , clockwise: true)
            
            path.addArc(withCenter: CGPoint(x: frame.width, y: frame.height * 5 / 6 - radius2), radius: radius2, startAngle: CGFloat.pi / 2 + angle2 , endAngle: CGFloat.pi / 2 , clockwise: false)
            path.addLine(to: CGPoint(x: frame.width, y: 0))
            path.addLine(to: CGPoint(x: 0, y: 0))
            path.addLine(to: CGPoint(x: 0, y: startPoint))

            
            context.setFillColor(UIColor(named: "primary")!.cgColor)
            context.addPath(path.cgPath)
            context.drawPath(using: .fill)
        }
        
        
    }
}
