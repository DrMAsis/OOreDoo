//
//  RippleView.swift
//  fine_posture
//
//  Created by Mahsa on 4/8/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import UIKit

class RippleView : UIView
{
    private let rippleCount = 4
    private var rippleViews = [UIView]()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        commonInit()
    }
    
    func commonInit()
    {
        self.backgroundColor = UIColor.clear
        for _ in 0..<rippleCount
        {
            let circle = UIView()
            circle.layer.borderColor = UIColor.white.cgColor
            circle.layer.borderWidth = 1
            circle.alpha = 0
            rippleViews.append(circle)
            
            addSubview(circle)
        }

    }
    
    override func layoutSubviews() {
        
        for (i , circle) in rippleViews.enumerated()
        {
            let height = frame.height - ( CGFloat(i) *  30)
            circle.frame.origin = CGPoint(x: (frame.width - height) / 2, y: (frame.height - height) / 2 )
            circle.frame.size = CGSize(width: height , height: height)
            circle.layer.cornerRadius = circle.frame.height / 2
            
            
            UIView.animate(withDuration: 1, delay: TimeInterval(Double(i) * 0.25), options: [.repeat,.autoreverse], animations: {
                self.rippleViews[i].alpha = 1.0
            })
        }
        
    }
    
    public func startRipple()
    {
        for i in 0..<rippleViews.count
        {
            UIView.animate(withDuration: 1, delay: TimeInterval(Double(i) * 0.25), options: [.repeat,.autoreverse], animations: {
                self.rippleViews[i].alpha = 1.0
            })
        }
    }
    
    public func stopRipple()
    {
        for i in 0..<rippleViews.count
        {
            self.rippleViews[i].layer.removeAllAnimations()
            self.rippleViews[i].alpha = 0
        }
        self.layoutIfNeeded()
    }
}
