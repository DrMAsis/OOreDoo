//
//  SettingCircleView.swift
//  fine_posture
//
//  Created by Mahsa on 4/21/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import UIKit

protocol SettingCircleDelegate {
    func valueChanged(angle : Double , positive : Double , negative : Double)
}

class SettingCircleView: UIView
{
    private let steps = 90
    private var stepRadian : CGFloat!
    
    private var circle : CGRect!
    private var padding : CGFloat!
    
    public var delegate : SettingCircleDelegate?
    
    
    private let startColor = UIColor(red: 50 / 244, green: 182 / 255, blue: 38 / 255, alpha: 1)
    private let endColor = UIColor(red: 107 / 255, green: 98 / 255, blue: 20 / 255, alpha: 1)
    private let disableColor = UIColor(red: 211 / 255, green: 211 / 255, blue: 211 / 255, alpha: 1)
    private let disableDummyColor = UIColor(red: 235 / 255, green: 235 / 255, blue: 235 / 255, alpha: 1)

    
    private let shapeLayer = CAShapeLayer()
    private let gradientLayer = CAGradientLayer()
    
    private let triangleImage = UIImageView(image: UIImage(named: "img_triangle"))
    private let dummyTop = UIImageView(image: UIImage(named: "img_dummy_top"))
    private let dummyBottom = UIImageView(image: UIImage(named: "img_dummy_bottom"))
    
    private let nDummyTop = UIImageView(image: UIImage(named: "img_dummy_top_pale"))
    private let nTriangleImage = UIImageView(image: UIImage(named: "img_triangle"))

    
    private let pDummyTop = UIImageView(image: UIImage(named: "img_dummy_top_pale"))
    private let pTriangleImage = UIImageView(image: UIImage(named: "img_triangle"))

    
    private var dummyWidth : CGFloat!
    private var dummyBottomHeight : CGFloat!
    private var dummyTopHeight : CGFloat!
    
    
    public var angle : Double = 90
    public var pAngle : Double = 5
    public var nAngle : Double = 5
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        commonInit()
    }
    
    func commonInit()
    {
        
        let color = UIColor(named: "primary")!
        let paleColor = UIColor(red: 189/255, green: 231/255, blue: 235/255, alpha: 1)
        let positiveColor = UIColor(red: 243/255, green: 185/255, blue: 134/255, alpha: 1)
        
        triangleImage.frame.size = CGSize(width: 25, height: 25)
        self.addSubview(triangleImage)

        nTriangleImage.frame.size = CGSize(width: 20, height: 20)
        self.addSubview(nTriangleImage)
        
        pTriangleImage.frame.size = CGSize(width: 20, height: 20)
        self.addSubview(pTriangleImage)
        
        
        nDummyTop.contentMode = .scaleAspectFit
        nDummyTop.tintColor = paleColor
        addSubview(nDummyTop)
        setAnchorPoint(anchorPoint: CGPoint(x: 0.5, y: 1), view: nDummyTop)

        
        pDummyTop.contentMode = .scaleAspectFit
        pDummyTop.tintColor = positiveColor
        addSubview(pDummyTop)
        setAnchorPoint(anchorPoint: CGPoint(x: 0.5, y: 1), view: pDummyTop)

        
        dummyBottom.contentMode = .scaleAspectFit
        dummyBottom.tintColor = color
        addSubview(dummyBottom)
        
        
        dummyTop.contentMode = .scaleAspectFit
        dummyTop.tintColor = color
        addSubview(dummyTop)
        setAnchorPoint(anchorPoint: CGPoint(x: 0.5, y: 1), view: dummyTop)

        triangleImage.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panned)))
        triangleImage.isUserInteractionEnabled = true
        
        pTriangleImage.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panned)))
        pTriangleImage.isUserInteractionEnabled = true
        
        nTriangleImage.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panned)))
        nTriangleImage.isUserInteractionEnabled = true
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        guard padding == nil || circle == nil else
        {
            return
        }
        
        stepRadian = CGFloat.pi * 2 / CGFloat(steps)
        
        padding = bounds.height / 6
        let newHeight = frame.height - padding
        circle = CGRect(x: (frame.width - newHeight) / 2 , y: padding , width: newHeight, height: newHeight)
        
    }
    
    override func draw(_ rect: CGRect) {
        
        let drawingCirclePadding = 8 + (padding / 10)
        let drawingCircle = CGRect(x: circle.minX + drawingCirclePadding , y: circle.minY + drawingCirclePadding , width: circle.width - 2 * drawingCirclePadding, height: circle.height - 2 * drawingCirclePadding)
        
        if let context = UIGraphicsGetCurrentContext()
        {
            context.addEllipse(in: drawingCircle)
            context.setStrokeColor(UIColor(named: "primary")!.cgColor)
            context.setLineWidth(8)
            context.drawPath(using: .stroke)
        }
        
        let offset = CGPoint(x: circle.midX, y: circle.midY)
        let start : CGFloat = (circle.height / 2) - (1 * drawingCirclePadding / 3)
        let end : CGFloat = start + padding / 16
        
        let path = UIBezierPath()
        
        for i in 0 ..< self.steps
        {
            let x = cos(CGFloat(i) * stepRadian)
            let y = sin(CGFloat(i) * stepRadian)
            
            
            path.move(to: CGPoint(x: offset.x + x * start, y: offset.y + y * start))
            path.addLine(to: CGPoint(x: offset.x + x * end, y: offset.y + y * end))
        }
        
        shapeLayer.path = path.cgPath
        shapeLayer.lineWidth = 4
        shapeLayer.lineCap = .round
        shapeLayer.strokeColor = endColor.cgColor
        
        gradientLayer.frame = CGRect(origin: .zero, size: frame.size)
        gradientLayer.colors = [startColor.cgColor , endColor.cgColor]
        
        gradientLayer.startPoint = CGPoint(x: 0.5 , y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        gradientLayer.mask = shapeLayer
        
        self.layer.addSublayer(gradientLayer)
        
        
        
        dummyWidth = 0.2 * circle.width
        dummyBottomHeight = 0.2 * circle.height
        dummyTopHeight = 0.37 * circle.height
        
        
        dummyTop.frame.size = CGSize(width: dummyWidth , height: dummyTopHeight)
        dummyTop.frame.origin = CGPoint(x: circle.midX - (dummyWidth / 2), y: circle.midY - dummyTopHeight)
        
        pDummyTop.frame.size = CGSize(width: dummyWidth , height: dummyTopHeight)
        pDummyTop.frame.origin = CGPoint(x: circle.midX - (dummyWidth / 2), y: circle.midY - dummyTopHeight)
        
        nDummyTop.frame.size = CGSize(width: dummyWidth , height: dummyTopHeight)
        nDummyTop.frame.origin = CGPoint(x: circle.midX - (dummyWidth / 2), y: circle.midY - dummyTopHeight)

        
        dummyBottom.frame.size = CGSize(width: dummyWidth, height: dummyBottomHeight)

        let dummyBottomDistance = circle.midY - 0.24 * dummyBottomHeight
        
        dummyBottom.frame.origin = CGPoint(x: circle.midX - (dummyWidth / 2), y: dummyBottomDistance)
        
    }
    
    
    
    @objc func panned(_ sender : UIPanGestureRecognizer)
    {
        
        if sender.state == .changed
        {
            let location = sender.location(in:self)
            
            let dx = location.x - self.circle.midX
            let dy = location.y - self.circle.midY
            
            var angle = atan2(abs(dy),abs(dx))
            
            if dx > 0 && dy > 0 {
                angle = -angle
            }
            else if dx < 0 && dy < 0
            {
                angle = CGFloat.pi - angle
            }
            else if dx < 0 && dy > 0
            {
                angle = CGFloat.pi + angle
            }
            
            switch sender.view
            {
            case triangleImage :
                setAngle(angle: Double(angle * 180) / Double.pi)
                
            case pTriangleImage:
                setPositiveAngle(angle: Double(angle * 180) / Double.pi)

            case nTriangleImage:
                setNegativeAngle(angle: Double(angle * 180) / Double.pi)

            default:
                break
            }
        }
        
    }
    
    
    func setAngle( angle : Double )
    {
        guard circle != nil , angle > 0 , angle < 180  else{
            return
        }
        
        let radianAngle = CGFloat(-angle) * CGFloat.pi / 180
        let transformAngle = radianAngle - (3 * CGFloat.pi / 2)
        
        
        let x = cos(radianAngle)
        let y = sin(radianAngle)
        
        let offset = CGPoint(x: circle.midX , y: circle.midY)
        let position : CGFloat = (circle.height / 2) + padding / 2
        
        
        UIView.animate(withDuration: 0.5) {
            
            
            self.triangleImage.transform = CGAffineTransform(rotationAngle: transformAngle)
            self.triangleImage.center = CGPoint(x: offset.x + x * position, y: offset.y + y * position)
            self.dummyTop.transform = CGAffineTransform(rotationAngle: transformAngle)
            
        }
        
        self.angle = angle
        
        let positive = abs(self.angle - pAngle)
        let negative = abs(self.angle - nAngle)
        
        
        delegate?.valueChanged(angle: self.angle, positive: positive  , negative: negative)
    }
    
    func setPositiveAngle( angle : Double )
    {
        guard circle != nil , angle >= self.angle , angle <= 180 else {
            return
        }
        
        let radianAngle = CGFloat(-angle) * CGFloat.pi / 180
        let transformAngle = radianAngle - (3 * CGFloat.pi / 2)
        
        
        let x = cos(radianAngle)
        let y = sin(radianAngle)
        
        let offset = CGPoint(x: circle.midX , y: circle.midY)
        let position : CGFloat = (circle.height / 2) + padding / 3
        
        
        
        UIView.animate(withDuration: 0.5) {
            
            
            self.pTriangleImage.transform = CGAffineTransform(rotationAngle: transformAngle)
            self.pTriangleImage.center = CGPoint(x: offset.x + x * position, y: offset.y + y * position)
            self.pDummyTop.transform = CGAffineTransform(rotationAngle: transformAngle)
            
        }
        
        pAngle = angle
        
        
        let positive = abs(self.angle - pAngle)
        let negative = abs(self.angle - nAngle)
        
        
        delegate?.valueChanged(angle: self.angle, positive: positive  , negative: negative)
    }
    
    func setNegativeAngle( angle : Double )
    {
        guard circle != nil , angle <= self.angle , angle >= 0 else {
            return
        }
        
        let radianAngle = CGFloat(-angle) * CGFloat.pi / 180
        let transformAngle = radianAngle - (3 * CGFloat.pi / 2)
        
        
        let x = cos(radianAngle)
        let y = sin(radianAngle)
        
        let offset = CGPoint(x: circle.midX , y: circle.midY)
        let position : CGFloat = (circle.height / 2) + padding / 3
        
        
        UIView.animate(withDuration: 0.5) {
            
            
            self.nTriangleImage.transform = CGAffineTransform(rotationAngle: transformAngle)
            self.nTriangleImage.center = CGPoint(x: offset.x + x * position, y: offset.y + y * position)
            self.nDummyTop.transform = CGAffineTransform(rotationAngle: transformAngle)
            
        }
        
        nAngle = angle
        
        
        let positive = abs(self.angle - pAngle)
        let negative = abs(self.angle - nAngle)
        
        
        delegate?.valueChanged(angle: self.angle, positive: positive  , negative: negative)
    }
    
    func setAnchorPoint(anchorPoint: CGPoint, view: UIView) {
        
        var newPoint = CGPoint(x: view.bounds.size.width * anchorPoint.x, y: view.bounds.size.height * anchorPoint.y)
        var oldPoint = CGPoint(x: view.bounds.size.width * view.layer.anchorPoint.x, y: view.bounds.size.height * view.layer.anchorPoint.y)
        
        newPoint = newPoint.applying(view.transform)
        oldPoint = oldPoint.applying(view.transform)
        
        var position : CGPoint = view.layer.position
        
        position.x -= oldPoint.x
        position.x += newPoint.x
        
        position.y -= oldPoint.y
        position.y += newPoint.y
        
        view.layer.position = position
        view.layer.anchorPoint = anchorPoint
    }
    
    
}

