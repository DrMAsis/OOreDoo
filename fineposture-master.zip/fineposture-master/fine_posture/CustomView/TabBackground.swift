//
//  TabBackground.swift
//  fine_posture
//
//  Created by Mahsa on 3/31/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import UIKit

class TabBackground: UIView {
    
    var centerCircleRadius : CGFloat!
    var sideCircleRadius : CGFloat!
    var verticalOffset : CGFloat!
    var horizontalOffset : CGFloat!
    var angle : CGFloat!
    
    override func layoutSubviews() {
        
        centerCircleRadius = frame.height * 0.5
        sideCircleRadius = centerCircleRadius
        
        verticalOffset = 0.2 * frame.height
        angle = asin(verticalOffset / (2 * centerCircleRadius))
        horizontalOffset = (2 * centerCircleRadius) * cos(angle)
    }
    
    override func draw(_ rect: CGRect) {
        
        
        if let context = UIGraphicsGetCurrentContext()
        {
            let path = UIBezierPath()
            path.move(to: .zero)
            path.addLine(to: CGPoint(x: self.frame.width / 2 - horizontalOffset, y: 0))
            
            path.addArc(withCenter: CGPoint(x: path.currentPoint.x , y: sideCircleRadius  ), radius: sideCircleRadius, startAngle: 3 * CGFloat.pi / 2 , endAngle: 2 * CGFloat.pi - angle , clockwise: true)
            
            path.addArc(withCenter: CGPoint(x: self.frame.width / 2, y: centerCircleRadius - verticalOffset), radius: centerCircleRadius, startAngle: CGFloat.pi - angle , endAngle: 2 * CGFloat.pi + angle , clockwise: false)
            
            path.addArc(withCenter: CGPoint(x: self.frame.width / 2 + horizontalOffset , y: sideCircleRadius), radius: sideCircleRadius, startAngle: CGFloat.pi + angle , endAngle: 3 * CGFloat.pi / 2, clockwise: true)
            
            path.addLine(to: CGPoint(x: frame.width, y: 0))
            
            path.addLine(to: CGPoint(x: frame.width, y: frame.height))
            path.addLine(to: CGPoint(x: 0 , y: frame.height))


            
            context.addPath(path.cgPath)
            context.setFillColor(UIColor(named: "primary")!.cgColor)
            context.drawPath(using: .fill)
        }
        
    }
    
}
