//
//  TabbarView.swift
//  fine_posture
//
//  Created by Mahsa on 3/31/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation
import UIKit

protocol TabbarDelegate {
    func didChangeTab(atIndex : Int)
}

class TabbarView: UIView {
    
    public var delegate : TabbarDelegate?
    
    let backgroundView = TabBackground()
    
    var images = [UIImageView]()
    var iconSize : CGSize!
    var imageWidth : CGFloat!
    
    var selectedIndex = 1
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        commonInit()
    }
    
    func commonInit()
    {
        backgroundColor = UIColor.clear
        backgroundView.backgroundColor = UIColor.clear
        addSubview(backgroundView)
        
        let image1 = UIImageView()
        image1.image = UIImage(named: "ic_setting")
        images.append(image1)
        
        let image2 = UIImageView()
        image2.image = UIImage(named: "ic_home_filled")
        images.append(image2)
        
        let image3 = UIImageView()
        image3.image = UIImage(named: "ic_stats")
        images.append(image3)

    }
    
    override func layoutSubviews() {
        
        iconSize = CGSize(width: self.frame.height / 2, height: self.frame.height / 2)
        backgroundView.frame = CGRect(x: -frame.width / 3, y: 0, width: frame.width * 5 / 3 , height: frame.height)
        
        imageWidth = self.frame.width / CGFloat(images.count)
        for i in 0..<images.count
        {
            images[i].frame.size = iconSize
            images[i].center = CGPoint(x: CGFloat(i) * imageWidth + imageWidth / 2, y: self.frame.height / 2)
            images[i].isUserInteractionEnabled = true
            images[i].addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTap(_:))))
            addSubview(images[i])
        }
        
        self.images[1].frame.origin.y = 0
    }
    
    @objc func didTap(_ sender : UITapGestureRecognizer)
    {
        images[0].image = UIImage(named: "ic_setting")
        images[1].image = UIImage(named: "ic_home")
        images[2].image = UIImage(named: "ic_stats")
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
            
            self.images[self.selectedIndex].frame.origin.y = self.iconSize.height / 2
            
            switch sender.view
            {
            case self.images[0]:
                self.images[0].image = UIImage(named: "ic_setting_filled")
                self.backgroundView.frame.origin.x = ( -2 * self.frame.width / 3)
                self.images[0].frame.origin.y = 0
                self.selectedIndex = 0
                
            case self.images[1]:
                self.backgroundView.frame.origin.x = ( -1 * self.frame.width / 3)
                self.images[1].image = UIImage(named: "ic_home_filled")
                self.images[1].frame.origin.y = 0
                self.selectedIndex = 1
                
            case self.images[2]:
                self.backgroundView.frame.origin.x = 0
                self.images[2].image = UIImage(named: "ic_stats_filled")
                self.images[2].frame.origin.y = 0
                self.selectedIndex = 2
            
            default:
                break
            }
            

        }, completion: nil)
        
        delegate?.didChangeTab(atIndex: selectedIndex)
    }
}
