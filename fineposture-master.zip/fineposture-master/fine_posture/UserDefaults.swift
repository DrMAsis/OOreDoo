//
//  UserDefault.swift
//  fine_posture
//
//  Created by Mahsa on 4/13/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import Foundation

extension UserDefaults
{
    public class Key {
        
        public static let SETTING_ON_OFF = "SETTING_ON_OFF"
        public static let SETTING_SET_POINT = "SETTING_SET_POINT"
        public static let SETTING_ERROR_POSITIVE = "SETTING_ERROR_POSITIVE"
        public static let SETTING_ERROR_NEGATIVE = "SETTING_ERROR_NEGATIVE"
        public static let SETTING_ALARM_DELAY = "SETTING_ALARM_DELAY"
        public static let SETTING_ALARM_VOLUME = "SETTING_ALARM_VOLUME"

    }
}
