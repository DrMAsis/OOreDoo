//
//  ConnectionVC.swift
//  fine_posture
//
//  Created by Mahsa on 4/8/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import UIKit
import SwiftEventBus

class ConnectionVC: UIViewController {
    
    @IBOutlet weak var disconnectView: UIView!
    @IBOutlet weak var ripple2: RippleView!
    @IBOutlet weak var ripple1: RippleView!
    @IBOutlet weak var retryButton: UIButton!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var backgroundView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        addBackgroundGradient()
        
        _ = BTConnection.shared
                
        SwiftEventBus.onMainThread(self, name: BTConnection.EVENT_CONNECTION_STATE) { result in
            
            self.notifyState()
            
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        self.notifyState()
    }
    
    
    override func viewDidLayoutSubviews() {
        
        retryButton.layer.cornerRadius = retryButton.frame.height / 2
        
    }
    
    private func addBackgroundGradient()
    {
        
        let startColor = UIColor(red: 125/255, green: 163/255, blue: 61/255, alpha: 1)
        let endColor = UIColor(red: 53/255, green: 81/255, blue: 7/255, alpha: 1)
        
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [startColor.cgColor , endColor.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        gradientLayer.frame = self.view.frame
        self.backgroundView.layer.addSublayer(gradientLayer)
    }
    
    func notifyState()
    {
        switch BTConnection.shared.connectionState {
            
        case .Connected:
            let vc = storyboard?.instantiateViewController(withIdentifier: "MainVC")
            self.show(vc!, sender: nil)
            
        case .Searching:
            ripple1.startRipple()
            ripple2.startRipple()
            
            statusLabel.text = "Searching ..."
            retryButton.isHidden = true
            disconnectView.isHidden = true
            
        case .Connecting:
            ripple1.startRipple()
            ripple2.startRipple()
            
            statusLabel.text = "Connecting ..."
            retryButton.isHidden = true
            disconnectView.isHidden = true
            
        case .Disconnected:
            
            ripple1.stopRipple()
            ripple2.stopRipple()
            
            statusLabel.text = "Disconnected!"
            retryButton.isHidden = false
            disconnectView.isHidden = false
            
        case .Off:
            ripple1.stopRipple()
            ripple2.stopRipple()
            
            statusLabel.text = "Bluetooth is off!"
            retryButton.isHidden = false
            disconnectView.isHidden = false
        }
    }
    
    @IBAction func retryTapped(_ sender: Any) {
        
        BTConnection.shared.connect()
        
    }
}
