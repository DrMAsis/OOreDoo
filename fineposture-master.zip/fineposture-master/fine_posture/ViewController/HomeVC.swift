//
//  ViewController.swift
//  fine_posture
//
//  Created by Mahsa on 3/24/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import UIKit
import SwiftEventBus

class HomeVC: UIViewController {

    @IBOutlet weak var batteryImage: UIImageView!
    @IBOutlet weak var batteryLabel: UILabel!
    
    @IBOutlet weak var calibratedCircle: CalibratedCircleView!
    @IBOutlet weak var calibrateButton: UIButton!
    @IBOutlet weak var angleCircle: UIView!
    
    
    @IBOutlet weak var averageLabel: UILabel!
    @IBOutlet weak var currentErrorLable: UILabel!
    @IBOutlet weak var lastAlertLabel: UILabel!
    @IBOutlet weak var currentAngleLabel: UILabel!
    
    var timer : Timer!
    var angle = 60
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SwiftEventBus.onMainThread(self, name: BTConnection.EVENT_DATA_UPDATE) { result in
            
            self.notifyDataChanged()
            
        }
    }
    

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
    }

    
    private func notifyDataChanged()
    {
        averageLabel.text = "\(BTConnection.shared.finalMeanLog ?? 0)"
        currentErrorLable.text = "\(BTConnection.shared.finalError ?? 0)"
        lastAlertLabel.text = "\(BTConnection.shared.finalAlertNumLog ?? 0 )"
        currentAngleLabel.text = "\(BTConnection.shared.finalAng ?? 0)"
        
        calibratedCircle.setAngle(angle: Double(BTConnection.shared.finalError ?? 90) + 90)

        updateBatteryState(percentage: BTConnection.shared.finalBattery ?? 0)
    }
    
    private func updateBatteryState(percentage : Int?)
    {
        guard  percentage != nil  else {
            
            batteryLabel.isHidden = true
            batteryImage.isHidden = true
            return
            
        }
        
        batteryImage.isHidden = false
        batteryLabel.isHidden = false
        
        batteryLabel.text = "\(percentage!)%"
        
        if percentage! < 5
        {
            batteryImage.image = UIImage(named: "ic_battery_0")
        }
        else if percentage! <= 25
        {
            batteryImage.image = UIImage(named: "ic_battery_25")
        }
        else if percentage! <= 50
        {
            batteryImage.image = UIImage(named: "ic_battery_50")
        }
        else if percentage! <= 90
        {
            batteryImage.image = UIImage(named: "ic_battery_75")
        }
        else
        {
            batteryImage.image = UIImage(named: "ic_battery_100")
        }
    }
    
    @IBAction func calibrateTapped(_ sender: Any) {
        
        BTConnection.shared.writeValue(value: BTConnection.shared.finalAng!, for: BTConnection.shared.setPointChar)
        
        UserDefaults.standard.set(BTConnection.shared.finalAng!, forKey: UserDefaults.Key.SETTING_SET_POINT)
        SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        
    }
}

