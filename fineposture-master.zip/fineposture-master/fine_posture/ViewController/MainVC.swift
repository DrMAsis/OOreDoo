//
//  MainVC.swift
//  fine_posture
//
//  Created by Mahsa on 4/3/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import UIKit

class MainVC: UIViewController , TabbarDelegate {

    @IBOutlet weak var statsVC: UIView!
    @IBOutlet weak var settingVC: UIView!
    @IBOutlet weak var homeVC: UIView!
    @IBOutlet weak var tabbar: TabbarView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(appMovedToBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
        
        tabbar.delegate = self
        
        didChangeTab(atIndex: 1)
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func didChangeTab(atIndex: Int) {
        
        homeVC.isHidden = true
        settingVC.isHidden = true
        statsVC.isHidden = true
        
        switch atIndex {
        case 0:
            settingVC.isHidden = false
        case 1:
            homeVC.isHidden = false
        case 2:
            statsVC.isHidden = false
        default:
            break
        }
    }

    
    @objc func appMovedToBackground() {
        
        let isOnline = UserDefaults.standard.bool(forKey: UserDefaults.Key.SETTING_ON_OFF)
        
        BTConnection.shared.writeValue(value: isOnline ? 1 : 0, for: BTConnection.shared.realTimeChar)
        
        self.dismiss(animated: true, completion: nil)
    }
    
}
