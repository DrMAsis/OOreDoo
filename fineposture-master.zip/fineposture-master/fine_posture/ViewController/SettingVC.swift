//
//  SettingVC.swift
//  fine_posture
//
//  Created by Mahsa on 4/21/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import UIKit
import SwiftEventBus

class SettingVC: UIViewController , SettingCircleDelegate {

    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var alarmVolumeSlider: UISlider!
    @IBOutlet weak var alarmDelaySlider: UISlider!
    @IBOutlet weak var alarmVolumeValue: UILabel!
    @IBOutlet weak var alarmDelayValue: UILabel!
    @IBOutlet weak var negativeErrorValue: UILabel!
    @IBOutlet weak var positiveErrorValue: UILabel!
    @IBOutlet weak var calibratedValue: UILabel!
    @IBOutlet weak var negativeErrorLabel: UILabel!
    @IBOutlet weak var positiveErrorLabel: UILabel!
    @IBOutlet weak var calibratedAngleLabel: UILabel!
    @IBOutlet weak var powerSwitch: UISwitch!
    @IBOutlet weak var settingCircle: SettingCircleView!
    
    var power : Bool?
    var setPoint : Int?
    var positiveError : Int?
    var negativeError : Int?
    var alarmDelay : Int?
    var alarmVolume : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        SwiftEventBus.onMainThread(self, name: BTConnection.EVENT_SETTING_UPDATE) { result in
            
            self.notifyDataChanged()
            
        }
        settingCircle.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.notifyDataChanged()
    }
    
    override func viewDidLayoutSubviews() {
        saveButton.layer.cornerRadius = saveButton.frame.height / 2
    }
    
    func valueChanged(angle: Double, positive: Double, negative: Double) {
        
        self.setPoint = Int(angle)
        self.negativeError = Int(negative)
        self.positiveError = Int(positive)
        
        calibratedValue.text = "\(self.setPoint!) degrees"
        positiveErrorValue.text = "\(self.positiveError!) degrees"
        negativeErrorValue.text = "\(self.negativeError!) degrees"
        
        
    }
    
    private func notifyDataChanged()
    {
        powerSwitch.isOn = UserDefaults.standard.bool(forKey: UserDefaults.Key.SETTING_ON_OFF)
        
        alarmDelaySlider.value = Float(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ALARM_DELAY))
        alarmDelayValue.text = "\(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ALARM_DELAY))s"
        
        alarmVolumeSlider.value = Float(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ALARM_VOLUME))
        alarmVolumeValue.text = "\(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ALARM_VOLUME)) / 100"

        var setpoint = Double(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_SET_POINT))
        setpoint = setpoint == 0 ? 90 : setpoint
        
        let nAngle = setpoint - Double(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ERROR_NEGATIVE))
        let pAngle = setpoint + Double(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ERROR_POSITIVE))

        settingCircle.setAngle(angle: setpoint)
        settingCircle.setPositiveAngle(angle: pAngle )
        settingCircle.setNegativeAngle(angle: nAngle)
        
        
        calibratedValue.text = "\(Int(setpoint)) degrees"
        positiveErrorValue.text = "\(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ERROR_POSITIVE)) degrees"
        negativeErrorValue.text = "\(UserDefaults.standard.integer(forKey: UserDefaults.Key.SETTING_ERROR_NEGATIVE)) degrees"
    }
    
    @IBAction func didChangePower(_ sender: Any) {
        
        power = powerSwitch.isOn
        
    }
    
    @IBAction func alarmVolumeChanged(_ sender: Any) {
        
        alarmVolume = Int(alarmVolumeSlider.value)
        alarmVolumeValue.text = "\(alarmVolume!) / 100"

    }
    
    @IBAction func alarmDelayChanged(_ sender: Any) {
        
        alarmDelay = Int(alarmDelaySlider.value)
        alarmDelayValue.text = "\(alarmDelay!)s"

    }
    
    @IBAction func saveTapped(_ sender: Any) {
        
        if alarmDelay != nil
        {
            
            BTConnection.shared.writeValue(value: alarmDelay!, for: BTConnection.shared.vibrateTimeChar)
            UserDefaults.standard.set(alarmDelay, forKey: UserDefaults.Key.SETTING_ALARM_DELAY)
            alarmDelay = nil
        }
        
        if alarmVolume != nil
        {
            
            BTConnection.shared.writeValue(value: alarmVolume!, for: BTConnection.shared.volumeChar)
            UserDefaults.standard.set(alarmVolume, forKey: UserDefaults.Key.SETTING_ALARM_VOLUME)
            alarmVolume = nil

        }
        
        if power != nil
        {
            
            BTConnection.shared.writeValue(value: power! ? 1 : 0, for: BTConnection.shared.realTimeChar)
            UserDefaults.standard.set(power!, forKey: UserDefaults.Key.SETTING_ON_OFF)
            power = nil
        }
        
        if setPoint != nil
        {
            BTConnection.shared.writeValue(value: setPoint! , for: BTConnection.shared.setPointChar)
            UserDefaults.standard.set(setPoint, forKey: UserDefaults.Key.SETTING_SET_POINT)
            setPoint = nil
        }
        
        if positiveError != nil
        {
            BTConnection.shared.writeValue(value: positiveError! , for: BTConnection.shared.positiveErrorChar)
            UserDefaults.standard.set(positiveError, forKey: UserDefaults.Key.SETTING_ERROR_POSITIVE)
            positiveError = nil
        }
        
        if negativeError != nil
        {
            BTConnection.shared.writeValue(value: negativeError! , for: BTConnection.shared.negativeErrorChar)
            UserDefaults.standard.set(negativeError, forKey: UserDefaults.Key.SETTING_ERROR_NEGATIVE)
            negativeError = nil
        }
        
        
        SwiftEventBus.post(BTConnection.EVENT_SETTING_UPDATE)
        
        let alert = UIAlertController(title: "Setting", message: "Settings has changed successfully!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.show(alert, sender: nil)
    }
    
}
