//
//  StatsVC.swift
//  fine_posture
//
//  Created by Mahsa on 4/13/1398 AP.
//  Copyright © 1398 test. All rights reserved.
//

import UIKit
import Charts


struct logLoadStr {
    var date : Date = Date()
    var average : Int32 = 0
    var errorNum : Int32 = 0
}

class StatsVC: UIViewController {

    @IBOutlet weak var monthlyChart: BarChartView!
    @IBOutlet weak var monthlyAverageAngle: UILabel!
    @IBOutlet weak var monthlyAlertNumber: UILabel!
    
    
    @IBOutlet weak var weeklyChart: BarChartView!
    @IBOutlet weak var weeklyAverageAngle: UILabel!
    @IBOutlet weak var weeklyAlertNumber: UILabel!
    
    @IBOutlet weak var dailyChart: BarChartView!
    @IBOutlet weak var dailyAverageAngle: UILabel!
    @IBOutlet weak var dailyAlertNumber: UILabel!
    
    
    @IBOutlet weak var dayOfWeekLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var transparentView: UIView!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var selectedDate : Date!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        datePicker.datePickerMode = .date
        datePicker.maximumDate = Date()
        
        selectedDate = Date()
        setDate(selectedDate)
        
        setUpStats()
    }
    
    @IBAction func cancelTapped(_ sender: Any) {
        
        toggleDatePicker()
    }
    
    @IBAction func doneTapped(_ sender: Any) {
        
        selectedDate = datePicker.date
        setDate(selectedDate)
        setUpStats()
        toggleDatePicker()
    }
    
    private func setDate(_ date : Date)
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM"
        
        let calendar = Calendar.current
        
        dayLabel.text = "\(calendar.component(.day, from: date))"
        monthLabel.text = "\(dateFormatter.string(from: date))"
        yearLabel.text = "\(calendar.component(.year, from: date))"
        
        dateFormatter.dateFormat = "EEEE"
        dayOfWeekLabel.text = "\(dateFormatter.string(from: date))"
        
    }
    
    func toggleDatePicker()
    {
        if bottomConstraint.constant == 0
        {
            UIView.animate(withDuration: 0.5) {
                self.bottomConstraint.constant = -self.dateView.frame.height
                self.transparentView.alpha = 1

                self.view.layoutIfNeeded()
            }
            transparentView.isUserInteractionEnabled = true
        }
        else {
            UIView.animate(withDuration: 0.5) {
                self.bottomConstraint.constant = 0
                self.transparentView.alpha = 0.0
                
                self.view.layoutIfNeeded()
            }
            transparentView.isUserInteractionEnabled = false

        }
    }
    
    @IBAction func dateTapped(_ sender: Any) {
        
        toggleDatePicker()
    }
    
    
    var clearLog = [logLoadStr()]
    let calender = Calendar.current
    
    var useWeekValueFormatter : weekValueFormatter = weekValueFormatter()
    var useMonthValueFormatter : monthValueFormatter = monthValueFormatter()

    private func setUpStats() {
        //manage and clear saved log
        var tempErrorNum = 0
        var tempMean : Double = 0
        var tempMeanNum : Double = 0
        if let tempLogs = CoreDataHandler.fetchLogObject() {
            if(tempLogs.count > 0) {
                clearLog.removeAll()
                print("all data count :\(tempLogs.count)")
                clearLog.append(logLoadStr(date: tempLogs.first!.date!, average: (tempLogs.first?.average)!, errorNum: (tempLogs.first?.errorNum)!))
                for tempLog in tempLogs {
                    if(compareLogDate(log1: clearLog.last!, log2: tempLog)) {
                        tempErrorNum += Int(tempLog.errorNum)
                        tempMean = tempMean + Double(tempLog.average)
                        tempMeanNum = tempMeanNum + 1
                    } else {
                        clearLog[clearLog.count - 1].average = Int32(tempMean/tempMeanNum)
                        clearLog[clearLog.count - 1].errorNum = Int32(tempErrorNum)
                        clearLog.append(logLoadStr(date: tempLog.date!, average: (tempLog.average), errorNum: (tempLog.errorNum)))
                        tempErrorNum = Int(tempLog.errorNum)
                        tempMean = Double(tempLog.average)
                        tempMeanNum = 1
                    }
                }
                clearLog[clearLog.count - 1].average = Int32(tempMean/tempMeanNum)
                clearLog[clearLog.count - 1].errorNum = Int32(tempErrorNum)
                
            }
        }
        else{
            print("no log data available")
        }
        //load first log data
        updateDayLog()
        updateWeekLog()
        updateMonthkLog()
        ///Day
        dailyChart.drawBarShadowEnabled = false
        dailyChart.drawValueAboveBarEnabled = true
        dailyChart.chartDescription?.enabled = false
        dailyChart.rightAxis.enabled = false
        dailyChart.noDataText = "There's No log for today"
        dailyChart.doubleTapToZoomEnabled = false
        dailyChart.pinchZoomEnabled = false
        
        
        let dayXAxis = dailyChart.xAxis
        dayXAxis.labelPosition = .bottom
        dayXAxis.labelFont = .systemFont(ofSize: 0)
        dayXAxis.drawAxisLineEnabled = false
        dayXAxis.labelTextColor = .white
        dayXAxis.labelCount = 1
        dayXAxis.centerAxisLabelsEnabled = false
        dayXAxis.granularity = 1
        
        
        let dayLeftAxis = dailyChart.leftAxis
        dayLeftAxis.drawLabelsEnabled = false
        dayLeftAxis.spaceTop = 0.25
        dayLeftAxis.spaceBottom = 0.25
        dayLeftAxis.axisMinimum = 0
        //        dayLeftAxis.axisMaximum = 100
        dayLeftAxis.drawAxisLineEnabled = false
        dayLeftAxis.drawZeroLineEnabled = true
        dayLeftAxis.drawGridLinesEnabled = false
        dayLeftAxis.zeroLineColor = .white
        dayLeftAxis.zeroLineWidth = 0.7
        ///Week
        weeklyChart.drawBarShadowEnabled = false
        weeklyChart.drawValueAboveBarEnabled = true
        weeklyChart.chartDescription?.enabled = false
        weeklyChart.rightAxis.enabled = false
        weeklyChart.noDataText = "There's No log for today"
        weeklyChart.doubleTapToZoomEnabled = false
        weeklyChart.pinchZoomEnabled = false
        
        
        let weekXAxis = weeklyChart.xAxis
        weekXAxis.labelPosition = .bottom
        weekXAxis.labelFont = .systemFont(ofSize: 13)
        weekXAxis.drawAxisLineEnabled = false
        weekXAxis.labelTextColor = .white
        weekXAxis.labelCount = 7
        weekXAxis.centerAxisLabelsEnabled = false
        weekXAxis.granularity = 1
        
        
        let weekLeftAxis = weeklyChart.leftAxis
        weekLeftAxis.drawLabelsEnabled = false
        weekLeftAxis.spaceTop = 0.25
        weekLeftAxis.spaceBottom = 0.25
        weekLeftAxis.drawAxisLineEnabled = false
        weekLeftAxis.drawZeroLineEnabled = true
        weekLeftAxis.zeroLineColor = .white
        weekLeftAxis.zeroLineWidth = 0.7
        weekLeftAxis.drawGridLinesEnabled = false
        ///Month
        monthlyChart.drawBarShadowEnabled = false
        monthlyChart.drawValueAboveBarEnabled = true
        monthlyChart.chartDescription?.enabled = false
        monthlyChart.rightAxis.enabled = false
        monthlyChart.noDataText = "There's No log for today"
        monthlyChart.doubleTapToZoomEnabled = false
        monthlyChart.pinchZoomEnabled = false
        monthlyChart.zoom(scaleX: CGFloat(5), scaleY: 0, x: 0, y: 0)
        
        
        
        let monthXAxis = monthlyChart.xAxis
        monthXAxis.labelPosition = .bottom
        monthXAxis.labelFont = .systemFont(ofSize: 13)
        monthXAxis.drawAxisLineEnabled = false
        monthXAxis.labelTextColor = .white
        monthXAxis.labelCount = 31
        monthXAxis.centerAxisLabelsEnabled = false
        monthXAxis.granularity = 1
        
        
        
        let monthLeftAxis = monthlyChart.leftAxis
        monthLeftAxis.drawLabelsEnabled = false
        monthLeftAxis.spaceTop = 0.25
        monthLeftAxis.spaceBottom = 0.25
        monthLeftAxis.drawAxisLineEnabled = false
        monthLeftAxis.drawZeroLineEnabled = true
        monthLeftAxis.zeroLineColor = .white
        monthLeftAxis.zeroLineWidth = 0.7
        monthLeftAxis.drawGridLinesEnabled = false
        
    }
    
    func compareLogDate (log1 : logLoadStr , log2 : Log) -> Bool {
        return (calender.component(.year, from: log1.date) == calender.component(.year, from: log2.date!) && calender.component(.month, from: log1.date) == calender.component(.month, from: log2.date!) && calender.component(.day, from: log1.date) == calender.component(.day, from: log2.date!))
        
    }

    func compareDates(date1: Date , date2: Date) ->Bool {
        return (calender.component(.year, from: date1) == calender.component(.year, from: date2) && calender.component(.month, from: date1) == calender.component(.month, from: date2) && calender.component(.day, from: date1) == calender.component(.day, from: date2))
    }

    func compareWeeks(date1: Date , date2: Date) ->Bool {
        return (calender.component(.year, from: date1) == calender.component(.year, from: date2) &&  calender.component(.weekOfYear, from: date1) == calender.component(.weekOfYear, from: date2))
    }
    
    func compareMonthes(date1: Date , date2: Date) ->Bool {
        return (calender.component(.year, from: date1) == calender.component(.year, from: date2) && calender.component(.month, from: date1) == calender.component(.month, from: date2))
    }
    
    ////update day log
    func updateDayLog() {
        var foundData : Bool = false
        var showAlert = 0
        for clear in clearLog {
            if compareDates(date1: clear.date , date2: selectedDate) {
                dailyAlertNumber.text = "\(clear.errorNum)"
                showAlert = Int(clear.errorNum)
                dailyAverageAngle.text = "\(clear.average)"
                foundData = true
                break
            }
        }
        
        if(!foundData) {
            dailyAlertNumber.text = "Nan"
            dailyAverageAngle.text = "Nan"
        }
        setChart(dataPoints: 1, values: [Double(showAlert)], chart: dailyChart , chartType: "day")
    }
    ////update Week Log
    func updateWeekLog() {
        var foundData : Bool = false
        var showAlert = 0
        var showAverage = 0
        var weekData : [logLoadStr] = []
        var weekAlerts = Array(repeating: 0.0, count: 7)
        weekData.removeAll()
        for clear in clearLog {
            if compareWeeks(date1: clear.date , date2: selectedDate) {
                showAlert += Int(clear.errorNum)
                showAverage += Int(clear.average)
                weekData.append(clear)
                foundData = true
            }
        }
        if(weekData.count != 0) {
            showAverage /= weekData.count
        }
        weeklyAlertNumber.text = "\(showAlert)"
        weeklyAverageAngle.text = "\(showAverage)"
        if(!foundData) {
            weeklyAlertNumber.text = "Nan"
            weeklyAverageAngle.text = "Nan"
        }
        for alert in weekData {
            weekAlerts[calender.component(.weekday, from: alert.date) - 1] = Double(alert.errorNum)
        }
        setChart(dataPoints: 7, values: weekAlerts, chart: weeklyChart,chartType: "week")
    }
    ////update month Log
    func updateMonthkLog() {
        var foundData : Bool = false
        var showAlert = 0
        var showAverage = 0
        var monthData : [logLoadStr] = []
        var monthAlerts = Array(repeating: 0.0, count: (calender.range(of: .day, in: .month, for: selectedDate)?.count)!)
        monthData.removeAll()
        for clear in clearLog {
            if compareMonthes(date1: clear.date , date2: selectedDate) {
                showAlert += Int(clear.errorNum)
                showAverage += Int(clear.average)
                monthData.append(clear)
                foundData = true
            }
        }
        
        if(monthData.count != 0) {
            showAverage /= monthData.count
        }
        monthlyAlertNumber.text = "\(showAlert)"
        monthlyAverageAngle.text = "\(showAverage)"
        if(!foundData) {
            monthlyAlertNumber.text = "Nan"
            monthlyAverageAngle.text = "Nan"
        }
        for alert in monthData {
            monthAlerts[calender.component(.day, from: alert.date) - 1] = Double(alert.errorNum)
        }
        
        setChart(dataPoints: (calender.range(of: .day, in: .month, for: selectedDate)?.count)! , values: monthAlerts, chart: monthlyChart,chartType: "month")
        monthlyChart.xAxis.labelCount = (calender.range(of: .day, in: .month, for: selectedDate)?.count)!
    }
    ///////////////////////////////////////////////////////////////////////////////////
    ////                                actions
    ///////////////////////////////////////////////////////////////////////////////////
    @IBAction func clearLog(_ sender: UIButton) {
        let alert = UIAlertController(title: "Do you want to Remove all log data?", message: "Careful there's no way back!", preferredStyle: .alert)
        
        self.present(alert, animated: true)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            if CoreDataHandler.fetchLogObject() != nil {
                _ = CoreDataHandler.deleteWholeLog()
            }
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { action in
            print("Nay")
        }))
        
    }
    
    @IBAction func dateChange(_ sender: UIDatePicker) {
        updateDayLog()
        updateWeekLog()
        updateMonthkLog()
    }
    
    ///////////////////////////////////////////////////////////////////////////////////
    ////                                chart funcs
    ///////////////////////////////////////////////////////////////////////////////////
    
    let barColor = UIColor(red: 134/256, green: 205/256, blue: 234/256, alpha: 1)
    func setChart(dataPoints: Int, values: [Double], chart : BarChartView, chartType : String) {
        var dataEntries: [BarChartDataEntry] = []
        for i in 0..<dataPoints {
            let dataEntry =   BarChartDataEntry(x: Double(i), y: Double(values[i]))
            dataEntries.append(dataEntry)
        }
        
        
        let colors = values.map { (entry) -> NSUIColor in
            if(chartType == "day") {
                return barColor
            } else if(chartType == "week") {
                return barColor
            } else {
                return barColor
            }
        }
        
        
        
        let chartDataSet = BarChartDataSet(values: dataEntries, label: nil)
        chartDataSet.colors = colors
        let chartData = BarChartData(dataSet: chartDataSet)
        chartData.dataSets[0].valueFont = .systemFont(ofSize: 15)
        if(chartType == "week") {
            chart.xAxis.valueFormatter = useWeekValueFormatter
        } else if (chartType == "month") {
            chart.xAxis.valueFormatter = useMonthValueFormatter
        }
        chartData.barWidth = 0.2
        chart.data = chartData
        chart.legend.enabled = false
        chart.scaleYEnabled = false
        chart.highlightPerTapEnabled = false
        chart.animate(xAxisDuration: 3, yAxisDuration: 3)
    }
    
    
    class weekValueFormatter : IAxisValueFormatter {
        let weekLabels = ["Sun",
                          "Mon",
                          "Tue",
                          "Wed",
                          "Thu",
                          "Fri",
                          "Sat"]
        func stringForValue(_ value: Double, axis: AxisBase?) -> String {
            return  weekLabels[Int(value)]
        }
    }
    class monthValueFormatter : IAxisValueFormatter {
        func stringForValue(_ value: Double, axis: AxisBase?) -> String {
            return  "\(Int(value) + 1)"
        }
    }
}
